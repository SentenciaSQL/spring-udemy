package com.bolsadeideas.springboot.backend.apirest.angular;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootBackendApirestAngularApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootBackendApirestAngularApplication.class, args);
	}

}
