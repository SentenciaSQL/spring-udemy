package com.bolsadeideas.springboot.di.app.models.sevice;

public interface IServicio {

	public String operacion();
	
}
