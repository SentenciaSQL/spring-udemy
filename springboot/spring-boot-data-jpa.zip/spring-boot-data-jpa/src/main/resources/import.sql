/* Populate tables */
INSERT INTO clientes (id, nombre, apellido, email, create_at) VALUES(10, 'Andres', 'Frias', 'afrias@eisdr.com', '2017-08-28');
INSERT INTO clientes (id, nombre, apellido, email, create_at) VALUES(11, 'Andres', 'Guzman', 'aguzman@eisdr.com', '2017-08-28');